# YouTube com Angular 7

![](https://cdn-images-1.medium.com/max/880/0*1Ufdwnk7Pu9pHegK)


Para o funcionamento correto é necesário informar uma key do **YOUTUBE API** em youtube.service.ts
Baixe o arquivo e na pasta do projeto, execute no terminal:
`npm install`



## Tutorial

[Integrando o YouTube com Angular 7](https://cdn-images-1.medium.com/max/880/0*RhDrCBog2jSYHWxk)


